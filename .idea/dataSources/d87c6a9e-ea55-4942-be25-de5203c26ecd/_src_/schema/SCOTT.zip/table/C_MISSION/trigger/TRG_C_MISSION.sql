CREATE TRIGGER TRG_C_MISSION
BEFORE INSERT
  ON C_MISSION
FOR EACH ROW WHEN (FOR EACH ROW )
begin
    SELECT seq_c_mission.nextval into:new.mid from dual;
  end;
/
