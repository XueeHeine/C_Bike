CREATE TRIGGER TRG_C_USER
BEFORE INSERT
  ON C_USER
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_user.nextval into:new.id from dual;
end;
/
