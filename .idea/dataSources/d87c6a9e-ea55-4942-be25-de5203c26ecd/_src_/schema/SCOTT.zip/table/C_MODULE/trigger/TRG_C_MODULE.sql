CREATE TRIGGER TRG_C_MODULE
BEFORE INSERT
  ON C_MODULE
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_module.nextval into:new.id from dual;
end;
/
