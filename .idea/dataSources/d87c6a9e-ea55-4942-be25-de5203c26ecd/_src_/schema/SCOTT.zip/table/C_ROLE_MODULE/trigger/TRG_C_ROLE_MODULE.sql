CREATE TRIGGER TRG_C_ROLE_MODULE
BEFORE INSERT
  ON C_ROLE_MODULE
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_C_role_module.nextval into:new.id from dual;
end;
/
