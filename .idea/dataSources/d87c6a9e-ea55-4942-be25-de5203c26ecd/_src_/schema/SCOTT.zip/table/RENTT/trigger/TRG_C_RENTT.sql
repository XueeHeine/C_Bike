CREATE TRIGGER TRG_C_RENTT
BEFORE INSERT
  ON RENTT
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_rentt.nextval into:new.id from dual;
end;
/
