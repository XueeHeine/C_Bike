CREATE TRIGGER TRG_C_ROLE
BEFORE INSERT
  ON C_ROLE
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_role.nextval into:new.id from dual;
end;
/
