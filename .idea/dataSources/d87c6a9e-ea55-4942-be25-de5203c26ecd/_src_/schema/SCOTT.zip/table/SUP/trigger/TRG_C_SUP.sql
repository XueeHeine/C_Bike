CREATE TRIGGER TRG_C_SUP
BEFORE INSERT
  ON SUP
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_sup.nextval into:new.id from dual;
end;
/
