CREATE TRIGGER TRG_C_BICYCLE
BEFORE INSERT
  ON BICYCLE
FOR EACH ROW WHEN (FOR EACH ROW )
begin
SELECT seq_c_bicycle.nextval into:new.id from dual;
end;
/
